public class Autos {
    //Atributos
     private String marca;
     private String modelo;
    private String color;
    private Double cilindraje;
    public String setModelo(){
        return this.modelo;
    }
    public void getModelo(String modelo){
        this.modelo=modelo;
    }
    public String setColor(){
        return this.color;
    }
    public void getColor(String color){
        this.color=color;
    }
    public Double setCilindraje(){
        return this.cilindraje;
    }
    public void getCilindarje(Double cilindraje){
        this.cilindraje=cilindraje;
    }
    public String setMarca(){
        return this.marca;
    }
    public void getMarca(String marca){
        this.marca=marca;
    }


    /// Metodos
    public String detalleAuto()
    {
        String da = " Modelo " + this.modelo +/// Añade datos
                " Diseño " + this.color+
                " Cilindraje " + this.cilindraje;
        return da;///
    }
    public String acelerar(int rpm)
    {
        return "El auto " + this.marca + "Esta acelerando a " + rpm + " rpm";
    }
    public Integer frenar(int m,int rpm,int t){
       return rpm*m/t;
    }
    public float Combustible(float L,float km){
        return km*L;/// Los metodos son las
    }
    public int Combustible(int L,int km){
        return km*L;/// Los metodos son las
    }
}
